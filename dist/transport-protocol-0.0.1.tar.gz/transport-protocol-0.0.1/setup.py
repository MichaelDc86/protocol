import setuptools


setuptools.setup(
    name='transport-protocol',
    version='0.0.1',
    author='Mike Lensky',
    author_email='',
    description='Transport protocol tools',
    url='',
    packages=setuptools.find_packages(),
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent"
    ]
)
